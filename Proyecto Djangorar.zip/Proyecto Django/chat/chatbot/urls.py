from django.urls import path
from .views import index, chat

urlpatterns = [
    path('', index, name='index'),  # URL para la interfaz de usuario
    path('api/chat/', chat, name='chat'),  # URL para la API de chat
]
