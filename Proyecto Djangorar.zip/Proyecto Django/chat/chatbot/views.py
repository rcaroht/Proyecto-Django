from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import requests
import json

# Vista para renderizar la plantilla de la interfaz de usuario

def index(request):
    return render(request, 'chat/index.html')  

# Vista para manejar las solicitudes de chat
@csrf_exempt
def chat(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        user_message = data['message']

        api_key = 'sk-proj-FcIfqF3SE3c5cxcLkunKT3BlbkFJQDAWtJCP7FdW6MhtM1Rz'  # Reemplaza con tu clave API de OpenAI
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}'
        }
        payload = {
            'prompt': user_message,
            'max_tokens': 150
        }

        response = requests.post(
            'https://api.openai.com/v1/engines/modelo-educativo-colegio-pioneros/completions',  # Reemplaza con tu endpoint personalizado
            headers=headers,
            json=payload
        )

        if response.status_code == 200:
            bot_response = response.json()['choices'][0]['text'].strip()
            return JsonResponse({'response': bot_response})
        else:
            return JsonResponse({'error': 'Error al conectarse con la API de OpenAI'}, status=500)

    return JsonResponse({'error': 'Método no permitido'}, status=405)

