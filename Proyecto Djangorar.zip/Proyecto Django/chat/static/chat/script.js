

const apiKey = OPENAI_API_KEY /*''*/ // clave API de OpenAI



app.use(bodyParser.json());
async function sendMessage() {
    const userMessage = document.getElementById('user-input').value;
    const response = await fetch('/chat/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': '{{ csrf_token }}'
        },
        body: JSON.stringify({ message: userMessage })
    });

    const data = await response.json();
    if (response.ok) {
        document.getElementById('response').innerText = data.response;
    } else {
        document.getElementById('response').innerText = data.error;
    }
}

app.post('/api/chat', async (req, res) => {
    const userMessage = req.body.message;

    try {
        const response = await axios.post(
            ENDPOINT , // endpoint | CHAT GPT PERSONALIZADO
            {
                prompt: userMessage,
                max_tokens: 150
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                }
            }
        );

        res.json({
            response: response.data.choices[0].text.trim()
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error al conectarse con la API de OpenAI');
    }
});

app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});


async function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    const response = await fetch('http://localhost:3000/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: userInput })
    });
    
    const data = await response.json();
    displayMessage('User', userInput);
    displayMessage('Bot', data.response);
}

function displayMessage(sender, message) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add(sender.toLowerCase());
    messageElement.innerText = `${sender}: ${message}`;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

